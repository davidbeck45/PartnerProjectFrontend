import React from 'react';
import { Routes, Route } from 'react-router-dom';

import StoreList from './StoreList';
import StoreForm from './StoreForm';
import StoreDetail from './StoreDetail';
import ItemForm from './ItemForm';
import ItemDetail from './ItemDetail';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/stores" element={<StoreList />} />
        {/* <Route path="/stores/new" element={<StoreForm />} />
        <Route path="/stores/:storeId" element={<StoreDetail />} />
        <Route path="/stores/:storeId/items/new" element={<ItemForm />} />
        <Route path="/stores/:storeId/items/:itemId" element={<ItemDetail />} /> */}
      </Routes>
    </div>
  );
}

export default App;
