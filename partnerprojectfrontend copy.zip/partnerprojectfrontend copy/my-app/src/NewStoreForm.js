import React, { useState } from 'react';

export default function NewStoreForm() {
  const [name, setName] = useState("");

  let handleSubmit = async (event) => {
        event.preventDefault();
        // Submit form data to server
        try{
            let res = await fetch(`http://localhost:3001/stores/new`, {
                method: "POST",
                body: JSON.stringify({
                    _id: "",
                    name: name,
                }),
                mode: 'cors',
                headers: {
                    'Content-Type': 'applications/json'
                }

        });
        let resJson = await res.json();
        if(res.satus === 200){
            setName("");
        }

    }catch (err){
        // console.log(err);
    }
    console.log(`Submitting new store with name: ${name}`);
  }

  return (
    <form onSubmit={handleSubmit}>
      <h2>Create a New Store</h2>
      <div>
        <label htmlFor="name">Name:</label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(event) => setName(event.target.value)}
        />
      </div>
      <button type="submit">Create Store</button>
    </form>
  );
}


