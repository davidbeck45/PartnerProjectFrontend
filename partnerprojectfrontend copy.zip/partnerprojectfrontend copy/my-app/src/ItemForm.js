// import { useState } from 'react';

// function ItemForm({ store_id }) {
//   const [itemName, setItemName] = useState('');

//   function handleSubmit(event) {
//     event.preventDefault();
//     console.log(itemName);

//     // TODO: send POST request to server to create new item

//     setItemName('');
//   }

//   return (
//     <div>
//       <h2>Add Item</h2>
//       <form onSubmit={handleSubmit}>
//         <div>
//           <label htmlFor="name">Name: </label>
//           <input
//             type="text"
//             id="name"
//             value={itemName}
//             onChange={(event) => setItemName(event.target.value)}
//           />
//         </div>
//         <button type="submit">Add Item</button>
//       </form>
//     </div>
//   );
// }

// export default ItemForm;
