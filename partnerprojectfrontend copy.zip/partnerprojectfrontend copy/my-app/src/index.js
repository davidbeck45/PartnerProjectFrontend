import React from 'react';
import { createRoot } from 'react-dom/client';
import { Routes, Route } from 'react-router-dom';
import App from './App';

import StoreDetail from './StoreDetail';
import NewStoreForm from './NewStoreForm';
import NewItemForm from './NewItemForm';
import ItemDetail from './ItemDetail';


import ReactDOM from 'react-dom/client';
import StoreList, {locateStores} from './StoreList';
import Wrapper from './Wrapper'
import {createBrowserRouter,RouterProvider} from 'react-router-dom'
import reportWebVitals from './reportWebVitals';

// createRoot(document.getElementById('root')).render(
//   <React.StrictMode>
//     <Routes>
//       <Route exact path="/" element={<App />} />
//       {/* <Route exact path="/stores" element={<StoreList />} />
//       <Route exact path="/stores/new" element={<NewStoreForm />} />
//       <Route exact path="/stores/:storeId" element={<StoreDetail />} />
//       <Route exact path="/stores/:storeId/items/new" element={<NewItemForm />} />
//       <Route path="/stores/:storeId/items/:itemId" element={<ItemDetail />} /> */}
//     </Routes>
    
//   </React.StrictMode>
// );

const router = createBrowserRouter([
  {
    path:"/",
    element:<Wrapper/>,
    children:[
      {path: "/stores",
        loader: locateStores,
        element: <StoreList/>,

      },
      {
        path: "/stores/new",
        
        element:(<NewStoreForm/>)
      },
      // {
      //   path: "/todo/new",
      //   element:(<CreateTodo/>)
      // }


    ]

  }

])


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router = {router} fallbackElement= {<div>Loading...</div>}></RouterProvider>
      
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();

