// import React, { useState } from 'react';

// function NewItemForm() {
//   const [name, setName] = useState('');
//   const [price, setPrice] = useState('');

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     // Submit form data to server
//     console.log(`Submitting new item with name: ${name} and price: ${price}`);
//   };

//   return (
//     <form onSubmit={handleSubmit}>
//       <h2>Create a New Item</h2>
//       <div>
//         <label htmlFor="name">Name:</label>
//         <input
//           type="text"
//           id="name"
//           value={name}
//           onChange={(event) => setName(event.target.value)}
//         />
//       </div>
//       <div>
//         <label htmlFor="price">Price:</label>
//         <input
//           type="text"
//           id="price"
//           value={price}
//           onChange={(event) => setPrice(event.target.value)}
//         />
//       </div>
//       <button type="submit">Create Item</button>
//     </form>
//   );
// }

// export default NewItemForm;
