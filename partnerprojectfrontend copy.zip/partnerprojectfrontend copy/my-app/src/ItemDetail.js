// function ItemDetail({ item }) {
//     return (
//       <div>
//         <h2>{item.name}</h2>
//         <p>Description: {item.description}</p>
//         <p>Price: {item.price}</p>
//         <button>Edit</button>
//         <button>Delete</button>
//       </div>
//     );
//   }
  
//   export default ItemDetail;
  