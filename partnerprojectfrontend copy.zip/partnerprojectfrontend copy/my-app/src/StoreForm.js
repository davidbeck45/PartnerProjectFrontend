// import React, { useState } from 'react';

// function StoreForm() {
//   const [name, setName] = useState('');

//   function handleSubmit(event) {
//     event.preventDefault();

//     fetch('/api/stores', {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify({ name }),
//     })
//       .then((response) => response.json())
//       .then(() => {
//         alert('Store created successfully!');
//         setName('');
//       });
//   }

//   return (
//     <div>
//       <h1>Create Store</h1>
//       <form onSubmit={handleSubmit}>
//         <label>
//           Name:
//           <input
//             type="text"
//             value={name}
//             onChange={(event) => setName(event.target.value)}
//           />
//         </label>
//         <button type="submit">Create</button>
//       </form>
//     </div>
//   );
// }

// export default StoreForm;
