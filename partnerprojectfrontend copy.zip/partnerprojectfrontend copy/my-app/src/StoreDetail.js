// import React, { useState, useEffect } from 'react';
// import { Link, useParams, Routes, Route } from 'react-router-dom';
// import NewItemForm from './NewItemForm';
// import ItemDetail from './ItemDetail';


// function StoreDetail() {
//   const [store, setStore] = useState({});
//   const { storeId } = useParams();

//   useEffect(() => {
//     fetch(`http://localhost:3001/stores/${storeId}`)
//       .then((response) => response.json())
//       .then((data) => {
//         setStore(data);
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   }, [storeId]);

//   return (
//     <div>
//       <h2>{store.name}</h2>
//       <p>{store.description}</p>
//       <h3>Items:</h3>
//       <ul>
//         {store.items &&
//           store.items.map((item) => (
//             <li key={item._id}>
//               <Link to={`/stores/${store._id}/items/${item._id}`}>{item.name}</Link>
//             </li>
//           ))}
//       </ul>
//       <Link to={`/stores/${store._id}/items/new`}>Add New Item</Link>

//       <Routes>
//         <Route
//           exact
//           path="/stores/:storeId/items/new"
//           element={<NewItemForm storeId={storeId} />}
//         />
//         <Route
//           path="/stores/:storeId/items/:itemId"
//           element={<ItemDetail storeId={storeId} />}
//         />
//       </Routes>
//     </div>
//   );
// }

// export default StoreDetail;
