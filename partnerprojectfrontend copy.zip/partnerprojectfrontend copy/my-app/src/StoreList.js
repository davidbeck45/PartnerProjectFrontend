// import React, { useState, useEffect } from 'react';

// function StoreList() {
//   const [stores, setStores] = useState([]);

//   useEffect(() => {
//     fetch('/api/stores')
//       .then((response) => response.json())
//       .then((data) => setStores(data));
//   }, []);

//   return (
//     <div>
//       <h1>Store List</h1>
//       <ul>
//         {stores.map((store) => (
//           <li key={store._id}>
//             <a href={`/stores/${store._id}`}>{store.name}</a>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// }

// export default StoreList;


import {Link, useLoaderData} from 'react-router-dom';

export default function StoreList(){

    const StoreList = useLoaderData();

    return(
        <div className = 'StoreList'>
            {StoreList.map((myStores) => (
                <div className = "stores" key = {myStores.id}>
                    <Link to={'${stores.id}'}><h1>{myStores.data} </h1> </Link>
                </div>
            ))}
        </div>
    )
}

async function locateStores(){

    const result = await fetch('http://localhost:3001', {
        method: "GET",
        mode: 'cors',
        headers: {
            'Content-Type': 'applications/json'
        }

    });
    return await result.json();
}

export {locateStores};
