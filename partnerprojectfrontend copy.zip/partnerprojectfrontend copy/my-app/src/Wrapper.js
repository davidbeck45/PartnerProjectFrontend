import {Link, Outlet} from 'react-router-dom'

export default function Wrapper(){
    return(
        <>
        <header>
            <Link to = "/stores">See All Stores</Link>
            <div> </div>
            <Link to = "/stores/new">Create Store</Link>
        </header>

        
        <Outlet/>
        
        </>

    );
}